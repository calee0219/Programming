// Solver: Min-Zheng Shieh
// Expected Running Time: <1 second

#include<cstdio>
#include<vector>
#include<algorithm>

using namespace std;

void solve()
{
	int n, b, r, ans=0;
	scanf("%d",&n);
	vector<int> p(1+n),d_go(1+n),d_ret(1+n),c(1+n);
	for(int i=1; i<=n; i++)
		scanf("%d%d%d",&p[i],&d_go[i],&c[i]);
	scanf("%d%d",&b,&r);
	vector<vector<int>> dp(r+1,vector<int>(2+n));

	// build prefix sum & d_ret
	// c[0]=p[0]=n; // done by vector
	for(int i=1; i<=n; i++)
	{
		c[i]+=c[i-1];
		p[i]+=p[i-1];
		d_ret[i]=d_go[i];
	}

	//rebuild d_go
	for(int i=1; i<n; i++)
	{
		for(int j=i+1; j<=n; j++)
		{
			d_go[j]=min(d_go[j],d_ret[i]+c[j-1]-c[i-1]);
		}
	}
   // ret[i]: you should return from ret[i] if you collect p[i] first
	// reward[i]: p[i]+...+p[ret[i]]
	vector<int> reward(n+1), ret(n+1);
	for(int i=1; i<=n; i++)
	{
		//ret[i]=0; // initialization is done by vector
		for(int j=i; j<=n; j++)
		{
			if(d_go[i]+d_ret[j]+c[j-1]-c[i-1]<=b)
			{
				reward[i]=p[j]-p[i-1];
				ret[i]=j;
			}
		}
	}
// initialization is done by vector
//	for(int i=0; i<=n; i++) dp[0][i]=0;
//	for(int i=0; i<=r; i++) dp[i][n+1]=0;
	for(int i=1; i<=r; i++)
	{
		for(int j=n; j>0; j--)
		{
			if(ret[j]==0) dp[i][j]=dp[i][j+1];
			else dp[i][j]=max(dp[i-1][ret[j]+1]+reward[j],dp[i][j+1]);
			ans=max(ans,dp[i][j]);
		}
	}
	printf("%d\n",ans);
}

int main()
{
	int nCases;
	scanf("%d",&nCases);
	while(nCases--) solve();
	return 0;
}
