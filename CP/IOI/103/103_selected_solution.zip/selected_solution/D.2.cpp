// Solver: Li-Chen Lan
// Expected running time: around 5 seconds

#include<iostream>
#include<cstdio>
#include<vector>
#include<cstring>
#include<algorithm>
using namespace std;
int n,t,l;
vector<pair<int,long long> > a[1000001];
int b[1000001];
bool used[1000001];
struct hnode
{
    int first;
    long long second,third;
};
vector<struct hnode > heap;

struct hnode make_hnode(int f,long long s,long long t)
{
    struct hnode tmp;
    tmp.first=f;
    tmp.second=s;
    tmp.third=t;
    return tmp;
}
bool cmp(struct hnode x,struct hnode y)
{
    return x.second>y.second;
}
int main()
{
    int i,j,k,ff,tt,ww;
    long long sumw;
    scanf("%d",&t);
    while(t--)
    {
        sumw=0;
        scanf("%d%d",&n,&l);
        for(i=0;i<n;i++)
        {
            a[i].clear();
        }
        for(i=0;i<n-1;i++)
        {
            scanf("%d%d%d",&ff,&tt,&ww);
            a[ff].push_back(make_pair(tt,ww));
            a[tt].push_back(make_pair(ff,ww));
            sumw+=ww;
        }
        memset(used,0,sizeof(used));
        heap.clear();
        for(i=0;i<n;i++)
        {
            b[i]=a[i].size();
            if(b[i]==1)
            {
                heap.push_back(make_hnode(a[i][0].first,a[i][0].second,a[i][0].second));
                used[i]=1;
            }
        }
        make_heap(heap.begin(),heap.end(),cmp);
        long long ans;
        ans=0;
        while(sumw>l)
        {
            struct hnode top;
            top=heap[0];
          //  cout<<top.first<<' '<<top.second<<endl;
            pop_heap(heap.begin(),heap.end(),cmp);heap.pop_back();
            b[top.first]--;
            sumw-=top.third;
            ans=top.second;
            if(b[top.first]==1)
            {
                used[top.first]=1;
                for(i=0;i<a[top.first].size();i++)
                {
                    if(used[a[top.first][i].first]==0)
                    {
                        heap.push_back(make_hnode(a[top.first][i].first,top.second+a[top.first][i].second,a[top.first][i].second));
                        push_heap(heap.begin(),heap.end(),cmp);
                        break;
                    }
                }
            }
        }
        cout<<ans<<endl;
    }
}

/*
2
8 0
2 5 6
1 2 5
5 6 6
3 1 9
6 7 15
7 0 12
4 3 12


















*/





